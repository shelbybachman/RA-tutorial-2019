% this script runs our function, my_function
% created by shelby, 2019

% to run this script, be sure that `my_function.m` is located in your 
% current working directory!

%% setup

clear all % clears the workspace
clc % clears the command window

%% create variables

% create a cell array that contains names of two individuals
name = {'shelby', 'yong'};

% create a vector that contains the age of each individual
age = [28 23];

% create a cell array that contains each individual's favorite food
food = {'sushi', 'kimchi'};

%% call my_function

% call my_function, which returns 
% (a) description, a cell array where each element is a description of each
% individual
% (b) birth_year, a vector where each array is the approximate year of
% birth for each individual
[description, birth_year] = my_function(name, age, food);

%% check outputs

% display the contents of the `description` output and the `birth_year`
% output, for each individual after the other
for ii = 1:length(description)
    disp(description{ii})
    disp(['Estimated year of birth for this person is: ' num2str(birth_year(ii))]) 
end

