function [description, birth_year] = my_function(name, age, food)

% this function takes three inputs: name (cell array), age (numeric), and food (cell array)
% and returns two outputs: description (cell array), birth year (numeric)
% requirements: all three inputs must be the same length

% check whether all inputs are equal in length
if (length(name) == length(age)) && (length(name) == length(food))
else
    error('Inputs are not equal in length. Try again!')
end

for ii = 1:length(name)
    % for each element of name, age, and animal, respectively, it concatenates a string that 
    % says "person #: name is age years old and likes to eat food'
    description{ii} = ['person #', num2str(ii), ': ', name{ii} ' is ' num2str(age(ii)) ' and likes to eat ' food{ii}];
   
    % for each element of age, it it returns the year of birth
    % (approximate) in the vector `birth_year'
    birth_year(ii) = 2019 - age(ii);
    
end

end

