% this script displays the stroop task instructions

global w

%%

text = ['Welcome to the experiment! \n\n'...
    'Press the spacebar to begin.'];

% draw text
DrawFormattedText(w, text, 'center', 'center', textColor);

% flip screen
Screen('Flip', w)

% wait for spacebar press
RestrictKeysForKbCheck(code_space); % restrict keys to spacebar only
KbStrokeWait; % wait for a single keypress
RestrictKeysForKbCheck([]); % re-enable all keys

text = ['In this task, you will see a series of words. \n\n'...
    'Your task is to press a key \n\n'...
    'to indicate the color in which the word is printed. \n\n\n\n'...
    'If the word is printed in BLUE, press the B key. \n\n'...
    'If the word is printed in GREEN, press the G key. \n\n'...
    'If the word is printed in RED, press the R key. \n\n\n\n'...
    'Press the spacebar to continue.'];

% draw text
DrawFormattedText(w, text, 'center', 'center', textColor);

% flip screen
Screen('Flip', w)

% wait for spacebar
RestrictKeysForKbCheck(code_space); % restrict keys to spacebar only
KbStrokeWait; % wait for a single keypress
RestrictKeysForKbCheck([]); % re-enable all keys

text = ['In between words, \n\n'...
    'you will see a cross at the center of the screen. \n\n'...
    'Please keep your eyes focused on the cross during this time. \n\n\n\n'...
    'When you are ready to begin the experiment, \n\n'...
    'press the spacebar.'];

% draw text
DrawFormattedText(w, text, 'center', 'center', textColor);

% flip screen
Screen('Flip', w)

% wait for spacebar
RestrictKeysForKbCheck(code_space); % restrict keys to spacebar only
KbStrokeWait; % wait for a single keypress
RestrictKeysForKbCheck([]); % re-enable all keys

% bonus: package the 3 commands that allow us to wait for a press of the
% spacebar into a single script, waitForSpacebar.m, and run that script above
% instead of repeating the commands above