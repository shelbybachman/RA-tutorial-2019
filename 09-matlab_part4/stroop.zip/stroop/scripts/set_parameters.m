% this script sets experimental parameters for the stroop task

%% trial-related parameters

% set the number of trials, nTrials, to be 36


% create a vector, trial, that goes from 1 to nTrials


% set the possible words (possible_words) to be blue, green, and red


% set the possible colors (possible_colors) of the words to be blue, green, and red


% duplicate each set of words such that each has length nTrials
% and each word is displayed the same number of trials
% store the result in trial_word and trial_color, respectively



% randomize each trial_word and trial_color such that:
% (c) no word repeats more than twice in a row
% (d) no word is presented in the same color more than twice in a row
% also include a step that calculates whether each trial is congruent
% (trial_congruent, 1 or 0)
% and check that we have 1/3 congruent trials

count = 0;
while 1
    count = count + 1;
    
    % initialize check variables
    check1 = 1; check2 = 1; check3 = 1;
    
    % randomize the arrays as trial_word_rand and trial_color_rand

    
    % check that no word repeats more than twice in a row

    
    % check that no word is presented in the same color more than twice in
    % a row

    
    % check congruency of trials

    
    % break out of the loop if check1 and check2 and check3 all equal 1

    
 
end

% now create a cell array with three elements,
% one for each color we will present words in
% call the cell array rgb_val, and store the RGB value for
% blue in element 1, green in element 2, and red in element 3


% now create a new array, trial_color_code, as follows:
% 1 if word shown in blue
% 2 if word shown in green
% 3 if word shown in red
trial_color_code = [];



% compile the elements into a table that shows what will happen on each
% trial:
% trial, trial_word_rand, trial_color_rand, trial_color_code, trial_congruent
% the table should be named stroop_table
% (hint: look at the dimensions of your arrays first!)
stroop_table = table();

% now rename the table columns to have the following names:
% trial, word, color, color_code, congruent
stroop_table.Properties.VariableNames = 

%% results-related parameters

% now we will create a table to store results on each trial
% make a carbon copy of our stroop_table, stroop_results
stroop_results = 

% add several empty columns to the stroop_results table:
% stim_onset: time when stimulus came on-screen
% stim_offset: time when stimulus went off-screen
% resp_code: code of key that was pressed
% RT: reaction time in seconds
% all columns should contain NA for now




%% fixation cross-related parameters

% set the dimensions of the cross as fix_dim (how wide across the cross
% should be, in pixels)
fix_dim = 20;

% set the x coordinates of the cross as fix_x
fix_x = [-fix_dim fix_dim 0 0];

% set the y coordinates of the cross as fix_y
fix_y = [0 0 -fix_dim fix_dim];

% combine the x and y coordinates as a matrix, fix_coords
% with x coordinates in row 1
% and y coordinates in row 2
fix_coords = [fix_x; fix_y];

% set the width of the cross lines, fix_lineWidth, as 2
fix_lineWidth = 2;

%% keypress-related parameters

% set codes for relevant keys

% spacebar (call it code_space)


% r key (call it code_red)


% g key (call it code_green)


% b key (call it code_blue)


% join the b, g, r codes in a vector named keys_to_listen


%% timing-related parameters

% set the stimulus duration (duration_stim) to be 2s


% set the response window (resp_window) to also be 2s
% (in this version subject can respond as long as the stimulus is on
% screen, but you could make the values different)


% set the ISI to be 2s


%% text size-related parameters

% ideally we should make the stimulus text larger than that included in the
% instructions
% set the variable textSize_stim to be 40



