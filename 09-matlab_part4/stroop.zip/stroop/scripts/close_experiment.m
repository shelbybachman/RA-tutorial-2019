% this script shows a farewell screen and closes the experiment

global w

text = ['Great job! \n\n'...
    'You have finished the experiment. \n\n\n\n'...
    'Press the spacebar to exit.'];

% draw text
DrawFormattedText(w, text, 'center', 'center', textColor);

% flip screen
Screen('Flip', w);

% wait for spacebar
RestrictKeysForKbCheck(code_space); % restrict keys to spacebar only
KbStrokeWait; % wait for a keystroke (of the spacebar)
RestrictKeysForKbCheck([]); % re-enable all keys

% close all screens and exit
Screen('CloseAll')
sca


