% this script runs the trials of the stroop task
% shelby bachman, 2019

global w

%% enlarge text

Screen('TextSize', w, textSize_stim);

%% initial fixation

% draw fixation cross


% flip screen
[~, t0] = Screen('Flip', w); % we save the time when the fixation cross appears as t0

%% loop through trials: show stimulus and collect keypress

% TBA

%% if time: save color indicated by each response as a new column, resp_color

% create a function, get_resp_color, which takes three inputs;
% a keycode, the code for blue, the code for green, and the code for red,
% and outputs either 1, 2, or 3,
% depending on whether the b, g, or r key was pressed, respectively
% and returns NaN if the keyCode is NaN
% save the function in the `scripts` subdirectory

% then use the function in the code above to assign a code to each
% response, in a new column, resp_color



%% save results table

% use the writetable() command to save the results table to our
% previously-specified output file
% (note that you would probably want to save some parameters, too, 
% and you might even want to save to a file during every iteration of the
% trial loop, so as to minimize potential data loss)
writetable(stroop_table, outputFile)

%% return text to instruction size

Screen('TextSize', w, textSize);