% this script runs the trials of the stroop task
% shelby bachman, 2019

global w

%% enlarge text

Screen('TextSize', w, textSize_stim);

%% initial fixation

% draw fixation cross
Screen('DrawLines', w, fix_coords, fix_lineWidth, textColor, [centerX centerY], 2);

% flip screen
[~, t0] = Screen('Flip', w); % we save the time when the fixation cross appears as t0

%% loop through trials: show stimulus and collect keypress

for ii = 1:nTrials
    
    % draw stimulus text
    DrawFormattedText(w, stroop_table.word{ii}, 'center', 'center', rgb_val{stroop_table.color_code(ii)});
    
    % flip screen & start waiting for a response
    [~, stroop_results.stim_onset(ii)] = Screen('Flip', w);
    
    % wait for a response until stimulus disappears
    keyPressed = 0;
    while keyPressed == 0 && GetSecs < (stroop_results.stim_onset(ii) + duration_stim)
        
        % wait for a keypress
        [keyIsDown, secs, keyCode] = KbCheck;
        
        if keyIsDown == 1
            if any(ismember(find(keyCode == 1), keys_to_listen))
                stroop_results.RT(ii) = secs - stroop_results.stim_onset(ii); % save reaction time
                stroop_results.resp_code(ii) = find(keyCode == 1); % save code of pressed key
                keyPressed = 1;
            end
        end
        
    end
    
    % draw fixation cross
    Screen('DrawLines', w, fix_coords, fix_lineWidth, textColor, [centerX centerY], 2);

    % flip screen after stimulus duration
    [~, stroop_results.stim_offset(ii)] = Screen('Flip', w, stroop_results.stim_onset(ii) + duration_stim);
    
    % wait duration of ISI
    WaitSecs('UntilTime', stroop_results.stim_offset(ii) + duration_ISI);
    
end

%% if time: save color indicated by each response as a new column, resp_color

% create a function, get_resp_color, which takes three inputs;
% a keycode, the code for blue, the code for green, and the code for red,
% and outputs either 1, 2, or 3,
% depending on whether the b, g, or r key was pressed, respectively
% and returns NaN if the keyCode is NaN
% save the function in the `scripts` subdirectory

% then use the function in the code above to assign a code to each
% response, in a new column, resp_color
for ii = 1:height(stroop_results)
    stroop_results.resp_color(ii) = get_resp_color(stroop_results.resp_code(ii), code_blue, code_green, code_red);
end

%% save results table

% use the writetable() command to save the results table to our
% previously-specified output file
% (note that you would probably want to save some parameters, too, 
% and you might even want to save to a file during every iteration of the
% trial loop, so as to minimize potential data loss)
writetable(stroop_results, outputFile)

%% return text to instruction size

Screen('TextSize', w, textSize);