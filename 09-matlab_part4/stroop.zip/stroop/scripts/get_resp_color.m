function resp_color = get_resp_color(resp_code, code_blue, code_green, code_red)

% this function takes a key code
% and determines what color was indicated by the code
% it returns a 1 if b was pressed, 2 if g, 3 if r, and NaN otherwise

if isnan(resp_code)
    resp_color = NaN;
end

switch resp_code
    case code_blue
        resp_color = 1;
    case code_green
        resp_color = 2;
    case code_red
        resp_color = 3;
end

end

