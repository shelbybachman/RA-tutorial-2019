%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% RA tutorial week 9: matlab, part 4
% shelby bachman, 2019
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% this is the parent script for our stroop experiment

%% setup
clear all
close all
clc 

%% set directories

% set "root" directory, rootDir to a directory called "stroop"
% place this somewhere logical on your computer
rootDir = '/Users/shelbybachman/Documents/Mather_Lab/RA-tutorial-2019/09-matlab_part4/stroop';

% navigate into your rootDir
cd(rootDir)

% notice the following subdirectories within your rootDir:
% 'scripts' is where we will store scripts and functions for our experiment
% 'results' is where we will store results files for our experiment

% assign the full path to the results subdirectory to 'resultsDir'
resultsDir = [rootDir, filesep, 'results'];

% temporarily add the 'scripts' subdirectory to your matlab path
% this ensures that matlab will know where to "look" for scripts &
% functions we create
scriptsDir = [rootDir, filesep, 'scripts'];
addpath(genpath(scriptsDir));

%% get subject info

% ask the experimenter for a subject ID in a dialog box
% (note that you could also make this entire script a function,
% and use the ID as an argument to the function)

% use the inputdlg() function to do this
% store the result as subID
subID = inputdlg('Enter the subject ID: ');

% convert subID to a number (hint: convert to a string first)
subID = str2double(char(subID));

%% set output files

% we want to store a single file for each subject in our 'results'
% subdirectory (we will store the results as a .csv)

% create a filename, outputFile, which is the full filepath to this
% subject's file
% the format should be resultsDir/subID#_stroop.csv
outputFile = [resultsDir, filesep, num2str(subID), '_stroop.csv'];

%% set experimental parameters

% open the script set_parameters.m, located in your 'scripts' subdirectory

% run the script to set experimental parameters
set_parameters

%% listen to keyboard & hide cursor

% uncomment the line below when you are ready to run the task
%ListenChar(2); 
HideCursor;

%% set screen parameters & open a screen

% open the script open_screen.m, located in your 'scripts' subdirectory
% notice there is also a script, open_screen_partial.m
% these are very similar to the scripts we created last week

% run the script to open the screen (test with the partial screen version)
open_screen

%% run instructions

% open the script run_instructions.m, located in your 'scripts' subdirectory

% run the script to show the instructions
run_instructions

%% run trials

% open the script run_trials.m, located in your 'scripts' subdirectory

% run the script to go through the trials
run_trials


%% close experiment

% open the script close_experiment.m, located in your 'scripts'
% subdirectory

% run the script to close the experiment
close_experiment

%% show the cursor again

% uncomment the line below when you are ready to run the task
%ListenChar(0); 
ShowCursor;

%% bonus items (if time)

% add a step to check if the results file already exists,
% then ask if we want to overwrite

% add a random number generator which is unique for each subject

% save parameters as a mat file
