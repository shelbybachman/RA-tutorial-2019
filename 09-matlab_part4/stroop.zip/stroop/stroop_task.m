%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% RA tutorial week 9: matlab, part 4
% shelby bachman, 2019
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% this is the parent script for our stroop experiment

%% setup
clear all
close all
clc 

%% set directories

% set "root" directory, rootDir to a directory called "stroop"
% place this somewhere logical on your computer


% navigate into your rootDir


% notice the following subdirectories within your rootDir:
% 'scripts' is where we will store scripts and functions for our experiment
% 'results' is where we will store results files for our experiment

% assign the full path to the results subdirectory to 'resultsDir'


% temporarily add the 'scripts' subdirectory to your matlab path
% this ensures that matlab will know where to "look" for scripts &
% functions we create


%% get subject info

% ask the experimenter for a subject ID in a dialog box
% (note that you could also make this entire script a function,
% and use the ID as an argument to the function)

% use the inputdlg() function to do this
% store the result as subID


% convert subID to a number (hint: convert to a string first)


%% set output files

% we want to store a single file for each subject in our 'results'
% subdirectory (we will store the results as a .csv)

% create a filename, outputFile, which is the full filepath to this
% subject's file
% the format should be resultsDir/subID#_stroop.csv


%% set experimental parameters

% open the script set_parameters.m, located in your 'scripts' subdirectory

% run the script to set experimental parameters


%% listen to keyboard & hide cursor

% uncomment the line below when you are ready to run the task
%ListenChar(2); HideCursor;

%% set screen parameters & open a screen

% open the script open_screen.m, located in your 'scripts' subdirectory
% notice there is also a script, open_screen_partial.m
% these are very similar to the scripts we created last week

% run the script to open the screen (test with the partial screen version)


%% run instructions

% open the script run_instructions.m, located in your 'scripts' subdirectory

% run the script to show the instructions


%% run trials

% open the script run_trials.m, located in your 'scripts' subdirectory

% run the script to go through the trials


%% show the cursor again

% uncomment the line below when you are ready to run the task
%ListenChar(0); ShowCursor;

%% close experiment

% open the script close_experiment.m, located in your 'scripts'
% subdirectory

% run the script to close the experiment


%% bonus items (if time)

% add a step to check if the results file already exists,
% then ask if we want to overwrite

% add a random number generator which is unique for each subject

% save parameters as a mat file

% write a function that calculates the color indicated by each response key
% and use it to add a column, resp_color, to the dataframe
